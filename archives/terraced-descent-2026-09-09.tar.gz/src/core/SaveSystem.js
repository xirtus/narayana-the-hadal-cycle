import { expeditionProgress } from "../expedition/Spaces.js";
const KEY = "narayana.hadal.v1";
export const INITIAL_SAVE = {
  version: 1,
  incarnation: 1,
  memories: 0,
  hunts: 0,
  combatVictories: [],
  bestCombo: 0,
  restored: [],
  observed: [],
  expedition: expeditionProgress(),
  lamp: false,
  discovered: [],
  sanctuaries: [],
  encounters: [],
  chapter: 0,
  maxDepth: 0,
  objectiveStep: 0,
  started: false,
  species: "squid",
  position: [0, -12, 0],
  settings: {
    quality: "high",
    sound: true,
    volume: 0.45,
    sensitivity: 1,
    reduceMotion: false,
    turbo: true,
    uvStrength: 0.65,
    vision: "natural",
  },
};
export function validateSave(value) {
  if (!value || value.version !== 1) return structuredClone(INITIAL_SAVE);
  const s = { ...structuredClone(INITIAL_SAVE), ...value };
  s.expedition = expeditionProgress(value.expedition || {});
  s.lamp = !!value.lamp;
  for (const k of [
    "discovered",
    "sanctuaries",
    "encounters",
    "combatVictories",
    "restored",
    "observed",
  ])
    s[k] = Array.isArray(s[k])
      ? [...new Set(s[k].filter((x) => typeof x === "string"))]
      : [];
  if (
    !Array.isArray(s.position) ||
    s.position.length !== 3 ||
    !s.position.every(Number.isFinite)
  )
    s.position = [0, -12, 0];
  s.position = [
    Math.max(-10000, Math.min(10000, s.position[0])),
    Math.max(-11000, Math.min(-0.7, s.position[1])),
    Math.max(-10000, Math.min(10000, s.position[2])),
  ];
  for (const k of [
    "incarnation",
    "memories",
    "hunts",
    "bestCombo",
    "chapter",
    "maxDepth",
    "objectiveStep",
  ])
    s[k] = Number.isFinite(s[k]) ? Math.max(0, s[k]) : INITIAL_SAVE[k];
  s.species = s.species === "octopus" ? "octopus" : "squid";
  s.settings = { ...INITIAL_SAVE.settings, ...s.settings };
  if (!["low", "medium", "high", "ultra"].includes(s.settings.quality))
    s.settings.quality = "high";
  s.settings.turbo = s.settings.turbo !== false;
  s.settings.uvStrength = Number.isFinite(s.settings.uvStrength)
    ? Math.max(0, Math.min(1, s.settings.uvStrength))
    : 0.65;
  s.settings.vision = s.settings.vision === "spectral" ? "spectral" : "natural";
  s.settings.volume = Number.isFinite(s.settings.volume)
    ? Math.max(0, Math.min(1, s.settings.volume))
    : 0.45;
  s.settings.sensitivity = Number.isFinite(s.settings.sensitivity)
    ? Math.max(0.3, Math.min(2, s.settings.sensitivity))
    : 1;
  return s;
}
export class SaveSystem {
  constructor() {
    this.available = true;
    this.data = this.load();
  }
  load() {
    try {
      return validateSave(JSON.parse(localStorage.getItem(KEY)));
    } catch {
      return structuredClone(INITIAL_SAVE);
    }
  }
  save(patch = {}) {
    this.data = validateSave({ ...this.data, ...patch });
    try {
      localStorage.setItem(KEY, JSON.stringify(this.data));
      return true;
    } catch {
      this.available = false;
      return false;
    }
  }
}
